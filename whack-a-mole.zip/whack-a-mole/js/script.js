/*
Benjamin Guo
400582417
February 20th, 2025
Javascript for my whack-a-mole game
*/


window.addEventListener("load", function (event) {

    //declare relevant variables
    let scoreText = document.getElementById('score')
    let moles = document.querySelectorAll('.molepic')
    let start = document.getElementById('startButton')
    let restart = document.getElementById('restartButton')
    let replay = document.getElementById('replayButton')
    let help = document.getElementById('helpButton')
    let closeHelp = document.getElementById('closePopup')
    let startForm = document.getElementById('playerForm')
    let popup = document.getElementById('popup')
    let moleGrid = document.getElementById('moleGrid')
    let timerText = document.getElementById('timer')
    let timeLeft;
    let score = 0;

    //hide certain aspects of the page initially
    timer.style.visibility = 'hidden';
    start.style.visibility = 'hidden';
    restart.style.visibility = 'hidden';
    scoreText.style.visibility = 'hidden';



    let moleInterval;
    let gameOver = false;

    //function that updates game timer
    function updateTimer() {
        timerText.innerText = `Time Left: ${timeLeft}`;
    }

    //function that updates score
    function updateScore() {
        scoreText.innerText = `Score: ${score}`;
    }

    //function to hide all moles 
    function hideAllMoles() {
        for (let i = 0; i < moles.length; i++) {
            moles[i].style.visibility = 'hidden'; //hide the entire mole div so it cannot be interacted with
        }
    }

    hideAllMoles()

    //function to show a random mole on the grid
    function showRandomMole() {
        if (gameOver) return;

        hideAllMoles();
        let randomIndex = Math.floor(Math.random() * moles.length);
        setTimeout(function (event) {
            moles[randomIndex].style.visibility = "visible";
        }, 150); // 150ms delay for the blink effect

    }



    //function that makes a new mole appear if not clicked in time
    function startMoleInterval() {
        clearInterval(moleInterval)
        moleInterval = setInterval(function () {
            showRandomMole(); // Show a new mole every interval tick 
        }, 900);
        hideAllMoles()
    }



    //function that handles game time (30 seconds)
    function startGameTimer() {

        updateTimer()

        gameTimer = setInterval(function () {
            if (timeLeft > 0) {
                timeLeft--;
                updateTimer()
                timerText.innerText = `Time Left: ${timeLeft}`;
            } else {
                clearInterval(gameTimer);
                gameOver = true;
                document.getElementById('gameover').style.visibility = 'visible';
                restart.style.visibility = "hidden";
                replay.style.visibility = "visible";
                hideAllMoles()
            }
        }, 1000);
    }

    //function that defines what happens when the game starts
    function startGame() {
        gameOver = false;
        score = 0;
        updateScore();

        document.getElementById("scoretime").style.display = "visible";
        timeLeft = 30;
        updateTimer();
        startMoleInterval();
        startGameTimer();
    }

    //function that defines what happens when the restart/replay button is clicked
    function resetGame() {
        clearTimeout(gameTimer);
        clearInterval(moleInterval);

        gameOver = true;

        score = 0;
        updateScore();




        help.style.visibility = 'visible';
        start.style.visibility = "visible";
        restart.style.visibility = "hidden";
        scoreText.style.visibility = "hidden";
        timer.style.visibility = "hidden";
        playerGreeting.style.visibility = "none";
        document.getElementById('gameover').style.visibility = 'hidden';
    }

    //dealing with clicking the moles
    for (let i = 0; i < moles.length; i++) {
        moles[i].addEventListener("click", function (event) {
            if (gameOver) return;
            hideAllMoles();

            score++;
            updateScore();

            clearInterval(moleInterval);
            setTimeout(function (event) {
                showRandomMole();
                startMoleInterval();
            }, 10);


        });
    }

    //Handle the submission of the introductory form
    startForm.addEventListener("submit", function (event) {
        event.preventDefault();

        //retrieve values of players name and players favorite colour
        let playerName = document.getElementById("playerName").value;
        let playerColor = document.getElementById("playerColor").value;

        //Check if valid inputs
        if (!playerName || !playerColor) {
            alert("Please fill all required information to start the game!");
            return;
        }


        //Hide form 
        introPage.style.display = "none";


        playerGreeting.innerText = `Hello, ${playerName}!`;

        playerGreeting.style.display = 'block';

        document.getElementById("scoretime").style.display = 'block';

        start.style.visibility = 'visible';
        moleGrid.style.backgroundColor = playerColor;

    })

    //clicking the help button
    help.addEventListener('click', function (event) {
        popup.style.display = 'block';
        start.style.visibility = 'hidden';
    })

    //clicking the close help button
    closeHelp.addEventListener('click', function (event) {
        popup.style.display = 'none';
        closeHelp.style.visiblity = 'hidden';
        start.style.visibility = 'visible';
    })
    
    //clicking the start button
    start.addEventListener('click', function (event) {
        let countdownElement = document.getElementById("countdown");
        countdownElement.style.visibility = "visible";

        let countdown = 3;

        timeLeft = 30;
        updateTimer();

        restart.style.visibility = 'hidden';
        help.style.visibility = 'hidden';

        countdownElement.innerText = countdown;

        let countdownInterval = setInterval(() => {
            countdown--;
            countdownElement.innerText = countdown;

            if (countdown === 0) {
                clearInterval(countdownInterval);
                countdownElement.innerText = "Go!";

                setTimeout(() => {
                    countdownElement.style.visibility = "hidden";
                    startGame();
                    restart.style.visibility = 'visible';
                }, 500);
            }
        }, 1000);



        start.style.visibility = 'hidden';
        scoreText.style.visibility = 'visible';
        timer.style.visibility = 'visible';
        playerGreeting.style.display = "block";

    })

    //clicking the restart button
    restart.addEventListener('click', function (event) {
        hideAllMoles();
        resetGame();
    })

    //clicking the replay button
    replayButton.addEventListener('click', function () {
        replay.style.visibility = "hidden";
        resetGame();

    });




})